﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
string nome = "viviane" ;
Console.WriteLine(" seja bem vindo " + nome);
string cidade = "Volta Redonda";
Console.WriteLine($"Eu gosto de {cidade}");

string sobrenome = "gomess", apelido;
int idade = 17;
Console.WriteLine(" idade: " + idade + " nome: " + nome);

byte valor = 255;
valor += 1;// valor = valor + 1;
Console.WriteLine("valor" + valor);

decimal salario = 5000.20m;
// como seria a declaração mais adaquada para variaveis que armazenem altura, peso e altura em nanometros:
float altura = 1.76f, peso = 83.2f;
double nanoaltura = altura * 0.0000000001;
Console.WriteLine($"A sua altura é {altura}m");
Console.WriteLine("Se vc pudesse ser o homem formiga,teria a altura" + "nm");
Console.WriteLine($"O peso foi informado foi: {peso}kg");
Console.WriteLine($"salario: {salario} ");

int val1 = 42, result = 0;
val1 = 32;

result = 10 + val1++; Console.WriteLine(result); // 42
result = 10 + ++val1; Console.WriteLine(result); // 44